# gamesnew_ — site de afiliados

## Como usar
1. Abra `index.html` no navegador para testar.
2. Edite a lista `products` no final do arquivo.
3. Troque `SEU_LINK_AQUI` pelo seu link de afiliado da Shopee.
4. Troque nome, preço, categoria e emoji pelos dados reais.
5. Para colocar imagens reais, substitua o conteúdo de `.thumb` por uma imagem ou adapte o card.

## Publicação gratuita
Você pode publicar este arquivo usando GitHub Pages, Cloudflare Pages ou Vercel.

## Categorias
- Gamer
- Setup
- Tech
- Até R$50

O site é responsivo e pensado primeiro para celular, que é o principal acesso vindo do TikTok.
